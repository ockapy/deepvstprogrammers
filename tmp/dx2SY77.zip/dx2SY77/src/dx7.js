// Liste de sysex
const SX = {
    start: 0xF0,
    end: 0xF7,
    yamaha: 0x43,
}

// Construction d'un mot de 14 bits avec deux mots de 7 bits qui se suivent en MIDI
const uInt14 = (b1,b2) => (b1 << 7) + b2;

// calcule le chechsumm sur 7 bits à partir d'un Uint8Array
const checksum7 = (array) => {
    // Somme de toute les entrées
    let sum = array.reduce((a,x)=>a+x);
    let inv = (~ sum) + 1;
    return inv & 0x7F;
}

class DX7 {

    voice;

    // Data : un ArrayBuffer
    constructor(data) {
        this.#analyse(data);
    }

    // Analyse an ArrayBuffer from a file
    #analyse(data) {
        // Vérification du type
        if (! 'byteLength' in data) {
            throw new Error("wrong type: byteLength expected")
        }
        // Vérifie la taille
        if (data.byteLength != 163) {
            throw new Error("wrong sysex file size: "+data.byteLength)
        }
        // Transforme en tableau typé (obligatoire à partir d'un ArrayBuffer)
        const sx = new Uint8Array(data);

        // Vérifie le début du sysex
        if (sx[0] != SX.start || sx[1] != SX.yamaha) {
            throw new Error("wrong sysex header: "+data[0]+' '+data[1])
        }
        // Vérifie le format
        if (sx[3] != 0) {
            throw new Error("wrong sysex format : voice expected")
        }
        // Vérifie la taille des données annoncées
        const datasize = uInt14(sx[4],sx[5]);
        const voiceSize = 155;
        if ( datasize != voiceSize ) {
            throw new Error("wrong sysex data size: "+datasize);
        }
        // Récupère séparément les données de voix
        const voice = sx.slice(6,voiceSize+6)
        
        // Vérifie le checksum
        const checksum = checksum7(voice);
        const sxsk = sx[voiceSize+6];
        if ( sxsk != checksum) {
            throw new Error("wrong sysex checksum: "+sxsk+" expected: "+checksum);
        }

        // Vérifie la fin du message exclusif
        if (sx[voiceSize+7] != SX.end) {
            throw new Error("wrong sysex end: "+sx[voiceSize+7]);
        }

        // Analyse une voix
        this.voice = new DX7voice(voice);
    }
}

// Definition of a DX7 voice
class DX7voice {
    constructor(data) {
        this.#analyse(data);
    }

    #analyse(data) {
        // Check correct size
        if (data.length != 155) {
            throw new Error("wrong voice size : "+data.length);
        }

        // Get all 6 operators
        // WARNING : operators are from 6 to 1 !
        this.op = {};
        let pos = 0;
        for(let i=6;i>0;i--) {
            this.op[i] = new DX7op(data.slice(pos,pos+21));
            pos += 21;
        }

        // Get name
        this.name = new TextDecoder().decode(data.slice(145,155));
    }
}

// Definition of a DX7 operator
class DX7op {
    constructor(data) {
        this.#analyse(data);
    }

    #analyse(data) {
        // Check correct size
        if (data.length != 21) {
            throw new Error("wrong operator size : "+data.length);
        }
        // Envelope Generator
        this.eg = new DX7eg(data.slice(0,8));
        // keyboard scaling
        this.scaling = new DX7scaling(data.slice(8,14));
        // operator sensitivity to modulation and velocity
        this.sensitivity = new DX7sensitivity(data.slice(14,16));
        // Output level
        this.output = data[16];
        // Oscillator
        this.osc = new DX7osc(data.slice(17,21));
    }
}

// Definition of a DX7 Envelope Generator
class DX7eg {
    constructor(data) {
        this.#analyse(data);
    }

    #analyse(data) {
        // Check correct size
        if (data.length != 8) {
            throw new Error("wrong Envelope Generator size : "+data.length);
        }
        // Get rate
        this.rate = [];
        for(let i = 0; i<4; i++) {
            this.rate[i] = data[i];
        }
        // Get level
        this.level = [];
        for(let i = 0; i<4; i++) {
            this.level[i] = data[i+4];
        }
    }
}

// Definition of keyboard scaling
class DX7scaling {
    constructor(data) {
        this.#analyse(data);
    }

    #analyse(data) {
        // Check correct size
        if (data.length != 6) {
            throw new Error("wrong scaling size : "+data.length);
        }
        this.break_point = data[0];
        this.left_depth = data[1];
        this.right_depth = data[2];
        this.left_curve = data[3];
        this.right_curve = data[4];
        this.rate = data[5];
    }
}

// Definition to sensitivity to modulator and key velocity
class DX7sensitivity {
    constructor(data) {
        this.#analyse(data);
    }
    #analyse(data) {
        // Check correct size
        if (data.length != 2) {
            throw new Error("wrong sensitivity size : "+data.length);
        }
        this.modulation = data[0];
        this.velocity = data[1];
    }
}

// Oscillator info
class DX7osc {
    constructor(data) {
        this.#analyse(data);
    }
    #analyse(data) {
        // Check correct size
        if (data.length != 4) {
            throw new Error("wrong oscillator size : "+data.length);
        }
        this.mode = data[0];
        this.frequency = {
            coarse: data[1],
            fine: data[2]
        };
        this.detune = data[3];
    }
}
