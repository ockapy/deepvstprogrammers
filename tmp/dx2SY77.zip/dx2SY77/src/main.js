const channel = 0x0; // 0 = midi channel 1 à 0xF
const format = 0x0;
const header = new Uint8Array([SX.start, SX.yamaha, channel, format]);

// Création d'un blob qui contient les données binaires
const makeSysexFile = function (data) {
    // Le premier paramètre doit êtr un tableau de parties qui seront assemblées
    let blob = new Blob([data], { type: 'application/octet-stream' });
    return window.URL.createObjectURL(blob);
}

// Attache le bouton download
const link = document.getElementById('downloadlink');
link.href = makeSysexFile(header);


// Lecture d'un fichier
let sysexData;
let dx7;

const loadSysexFile = function (event) {
    const input = event.target;
    const reader = new FileReader();
    // Callback quand la lecture est terminée
    reader.onload = function () {
        sysexData = reader.result;
        link.href = makeSysexFile(sysexData);
        dx7 = new DX7(sysexData);
    };
    reader.readAsArrayBuffer(input.files[0]);
};

const uploadFile = document.getElementById('uploadFile');
uploadFile.onchange = loadSysexFile;

